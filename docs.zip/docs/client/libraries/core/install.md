OneTrueError.Client installation
=================================

You've just installed the OneTrueError client library. 

We suggest that you read the [Getting started guide](../../gettingstarted.md) or read one of the links below

* [Getting started guide](../../gettingstarted.md)
* [Client API reference](http://onetrueerror.com/docs/api/client/)
* [Install OneTrueError server](http://onetrueerror.com/download/server/)

