Executuive summary

Can you answer the following questions:

* How many bugs are there in the application versions that your users are currently running?
* How many users are affected by those bugs? 

If you can't answer those questions, try asking your lead developer. Still a no go?

There are a lot of standardized way to measure code quality and technical debt. They are however an indication and not a gurantee that you won't have bugs in the versions that you release. 

OneTrueError give you hard facts. Once the system is installed you have hard facts about how your applicaion ***really*** is perfoming. You get an always up-to-date picture about the number of errors, the number of affected users for each error and even a heat map of the world to quickly identify where the bug happend.

In short, OneTrueError helps you stop making buisness decisions based on assumptions. The service allows you to prioritize bugs that have been proved to be critial.

