Extending
==========

You can extend the client library by either creating a library for a new framework or by adding a new context information collector.

# Extension points

* [Create a new client library](clientlib.md)
* [Creating a new context collector](contextprovider.md)
