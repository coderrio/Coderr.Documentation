# Adding support for a new database engine

1. Copy the SqlServer project
2. Add the new project (renamed) to the solution
3. Change the `database.sql` which are located in the root to follow the syntax of your dbengine
4. Modify all classes in the project to change the SQL syntax.

(rather sparse, will be expanded when support for the second engine is built)
